# Vault Signal Memory Capsule QR Guide

This QR links to the living memory capsule for Vault Signal.